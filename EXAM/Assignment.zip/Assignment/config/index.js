/* globals process module */

module.exports = {
    port: process.env.PORT || 3001
};