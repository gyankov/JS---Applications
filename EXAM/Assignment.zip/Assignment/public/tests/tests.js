mocha.setup('bdd');
const expect = chai.expect;

describe('Data tests', function () {
        const result = {};

describe('Data.getMaterials tests', function () {
    
    
    beforeEach(function (done) {
        sinon.stub()
    });
    
    
    describe('what?', function () {
        
    });
    
});

})
mocha.run();